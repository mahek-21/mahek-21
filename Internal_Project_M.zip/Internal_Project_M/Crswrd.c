#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<string.h>
void main()
{
  int qno,location,i,j;
  char ansuser;
  char ans[9][100]={"LAKES","TESLA","RAP","LATER","SAP","EEL","SNAKE"};
  printf("**SOLVE THE CROSSWORD PUZZLE !!!**\n");
  printf("\nThe empty grid :\n");
  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");

  printf("|\t1\t|\t\t|\t2\t|\t\t|\t3\t|\n");

  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");

  printf("|\t\t|\t\t|\t\t|\t\t|\t\t|\n");

  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");

  printf("|\t\t|\t\t|\t4\t|\t\t|\t\t|\n");

  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");

  printf("|\t5\t|\t\t|\t\t|\t\t|\t\t|\n");

  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");

  printf("|\t6\t|\t\t|\t\t|\t\t|\t\t|\n");

  for(i=0;i<81;i++)
  {
    printf("-");

  }
  printf("\n");
  printf("\nHere are the hints!\n");
  printf("\nHints for 'Down' :\n");
  printf("\n1.Water body\n2.A scientist with name famous as car brand\n3.Type of a song\n");
  printf("\nHints for 'Across' :\n");
  printf("\n1.Comparative degree for 'late'\n4.Fluid in xylem cells of plants\n5.A fish-like animal can cause electric shock\n6.A reptile with no legs\n");

  printf("\nEnter the the answers for the puzzle :\nNote:Enter all ans in caps!\n");
  abc:printf("\nEnter 1 for down, 0 for across and 2 for printing the answers with grid ");
  scanf("%d",&location);

  if (location==1)
  {
    printf("Enter the question no. you want to answer(1,2,3 down) ");
    scanf("%d",&qno);
    switch(qno)
    {
      case 1:
      {
        pqr:printf("Water body : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[0])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry, try again\n");
          goto pqr;
        }
      }
      break;
      case 2:
      {
        efg:printf("A scientist with name famous as car brand: ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[1])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry,try again\n");
          goto efg;
        }
      }
      break;
      case 3:
      {
        jkl:printf("Type of a song : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[2])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry,try again\n");
          goto jkl;
        }
      }
      break;
      default:
      {
        printf("Down contains only questions 1,2 and 3");
        goto abc;
      }
      break;

    }

  }
  else if(location==0)
  {
    printf("Enter the question number you want to answer S(1,4,5,6 across) ");
    scanf("%d",&qno);
    switch(qno)
    {
      case 1:
      {
        dsr:printf("Comparative degree for 'late' : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[3])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry, try again\n");
          goto dsr;
        }
      }
      break;
      case 4:
      {
        cvb:printf("Fluid in xylem cells of plants : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[4])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry, try again\n");
          goto cvb;
        }
      }
      break;
      case 5:
      {
        bmm:printf("A fish-like animal can cause electric shock : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[5])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry, try again\n");
          goto bmm;
        }
      }
      break;
      case 6:
      {
        ikl:printf("A reptile with no legs : ");
        scanf("%s",&ansuser);
        if (strcmp(&ansuser,ans[6])==0)
        {
          printf("Correct\n");
          goto abc;
        }
        else
        {
          printf("Sorry, try again\n");
          goto ikl;
        }
      }
      break;
      default:
      {
        printf("Across contains only questions 1,4,5 and 6.");
        goto abc;
      }
      break;
    }

  }
  else if (location==2)
  {
    printf("\nNow let us proceed to printing the grid!\nThe crossword grid :\n");
    for(i=0;i<81;i++)
    {
      printf("-");

    }
    printf("\n");
    j=0;
    while(ans[3][j]!='\0')
    {
      printf("|\t%c\t",ans[3][j]);
      j++;
    }
    printf("|\n");

    for(i=0;i<81;i++)
    {
      printf("-");

    }
    printf("\n");
    printf("|\t%c\t|",ans[0][1]);
    printf("\t\t|\t%c\t|\t\t|\t%c\t|",ans[1][1],ans[2][1]);
    printf("\n");
    for(i=0;i<81;i++)
    {
      printf("-");

    }
    printf("\n");

    printf("|\t%c\t|\t\t",ans[0][2]);

    j=0;
    while(ans[4][j]!='\0')
    {
      printf("|\t%c\t",ans[4][j]);
      j++;
    }
    printf("|\n");

    for(i=0;i<81;i++)
    {
      printf("-");

    }
    printf("\n");

    j=0;
    while(ans[5][j]!='\0')
    {
      printf("|\t%c\t",ans[5][j]);
      j++;
    }

    printf("|\t\t|\t\t|\n");

    for(i=0;i<81;i++)
    {
      printf("-");

    }
    printf("\n");

    j=0;
    while(ans[6][j]!='\0')
    {
      printf("|\t%c\t",ans[6][j]);
      j++;
    }
    printf("|\n");

    for(i=0;i<81;i++)
    {
      printf("-");
    }
    printf("\n");
  }

  else
  {
    printf("Wrong location. Enter down/across only!\n");
    goto abc;
  }
}
